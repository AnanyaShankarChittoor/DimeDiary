package com.project.dimediaryapp.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.recyclerview.widget.RecyclerView
import com.project.dimediaryapp.R
import com.project.dimediaryapp.model.Expense
import com.project.dimediaryapp.util.PreferenceHelper
import com.project.dimediaryapp.util.Util
class ExpensesAdapter(
    private val expensesList: List<Expense>,
    private val categoryIconMap: Map<String, Int>,
    private val clickListener: (Expense) -> Unit
) : RecyclerView.Adapter<ExpensesAdapter.ExpenseViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ExpenseViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_expense, parent, false)
        return ExpenseViewHolder(view)
    }

    override fun onBindViewHolder(holder: ExpenseViewHolder, position: Int) {
        val expense = expensesList[position]
        holder.bind(expense, categoryIconMap, clickListener)
    }

    override fun getItemCount(): Int = expensesList.size

    class ExpenseViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val expenseName: TextView = itemView.findViewById(R.id.textViewExpenseName)
        private val expenseCategory: TextView = itemView.findViewById(R.id.textViewExpenseCategory)
        private val expenseAmount: TextView = itemView.findViewById(R.id.textViewExpenseAmount)
        private val expenseIcon: ImageView = itemView.findViewById(R.id.imageViewCategoryIcon)
        private val expenseLayout: ConstraintLayout = itemView.findViewById(R.id.itemExpenseLayout)

        fun bind(expense: Expense, categoryIconMap: Map<String, Int>, clickListener: (Expense) -> Unit) {
            expenseName.text = expense.name
            expenseCategory.text = expense.category
            expenseAmount.text = expense.amount.toString()

            // Set the icon based on the expense category
            val iconResId = categoryIconMap[expense.category] ?: R.drawable.ic_view_expense
            expenseIcon.setImageResource(iconResId)

            // Set click listener on the entire layout
            expenseLayout.setOnClickListener { clickListener(expense) }
        }
    }
}
