package  com.project.dimediaryapp.model
data class Expense(
    var id: String = "",
    var amount: Int = 0,
    var category: String = "",
    var description: String = "",
    var name: String = "",
    var userId: String = ""
)
