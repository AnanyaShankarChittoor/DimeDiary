package com.project.dimediaryapp.fragments

import android.app.Dialog
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.widget.EditText
import android.widget.Switch
import android.widget.Toast
import androidx.fragment.app.DialogFragment
import com.google.android.material.chip.Chip
import com.google.android.material.chip.ChipGroup
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.project.dimediaryapp.R
import com.project.dimediaryapp.util.FirestoreUtil
import com.project.dimediaryapp.util.PreferenceHelper

class AddExpenseDialogFragment : DialogFragment() {

    private lateinit var expenseName: EditText
    private lateinit var expenseAmount: EditText
    private lateinit var switchDescription: Switch
    private lateinit var description: EditText
    private lateinit var chipGroupCategories: ChipGroup

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        val view = LayoutInflater.from(requireContext()).inflate(R.layout.fragment_add_expense_dialog, null)

        expenseName = view.findViewById(R.id.expenseName)
        expenseAmount = view.findViewById(R.id.expenseAmount)
        switchDescription = view.findViewById(R.id.switchDescription)
        description = view.findViewById(R.id.description)
        chipGroupCategories = view.findViewById(R.id.chipGroupCategories)

        switchDescription.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) {
                description.visibility = View.VISIBLE
            } else {
                description.visibility = View.GONE
            }
        }

        chipGroupCategories.setOnCheckedStateChangeListener { group, checkedIds ->
            // Responds to child chip checked/unchecked
        }

        return MaterialAlertDialogBuilder(requireContext())
            .setTitle("Add Expense")
            .setView(view)
            .setPositiveButton("Add") { _, _ ->
                if (validateInputs()) {
                    saveExpenseToFirestore()
                }
            }
            .setNegativeButton("Cancel") { dialog, _ ->
                dialog.dismiss()
            }
            .create()
    }
//
//    private fun setChipClickListener() {
//        for (i in 0 until chipGroupCategories.childCount) {
//            val chip = chipGroupCategories.getChildAt(i) as Chip
//            chip.setOnClickListener {
//                Toast.makeText(requireContext(), "Selected: ${chip.text}", Toast.LENGTH_SHORT).show()
//                chipGroupCategories.check(chip.id)
//                chip.isClickable = false
//                chip.isCheckable = false
//            }
//        }
//    }
//
//


    private fun validateInputs(): Boolean {
        if (expenseName.text.isNullOrEmpty()) {
            Toast.makeText(requireContext(), "Expense Name is required", Toast.LENGTH_SHORT).show()
            return false
        }
        if (expenseAmount.text.isNullOrEmpty()) {
            Toast.makeText(requireContext(), "Amount is required", Toast.LENGTH_SHORT).show()
            return false
        }
        if (chipGroupCategories.checkedChipId == View.NO_ID) {
            Toast.makeText(requireContext(), "Category is required", Toast.LENGTH_SHORT).show()
            return false
        }
        return true
    }

    private fun getSelectedChipValue(): String? {
        val selectedChipId = chipGroupCategories.checkedChipId
        if (selectedChipId != View.NO_ID) {
            val selectedChip: Chip? = chipGroupCategories.findViewById(selectedChipId)
            return selectedChip?.text?.toString()
        }
        return null
    }

    private fun saveExpenseToFirestore() {
        val userId = PreferenceHelper.getUserId(requireContext())
        if (userId == null) {
            Toast.makeText(requireContext(), "User ID is required", Toast.LENGTH_SHORT).show()
            return
        }

        val name = expenseName.text.toString()
        val amount = expenseAmount.text.toString().toDouble()
        val category = getSelectedChipValue()
        val descriptionText = if (description.visibility == View.VISIBLE) {
            description.text.toString()
        } else {
            ""
        }

        if (category == null) {
            Toast.makeText(requireContext(), "Category is required", Toast.LENGTH_SHORT).show()
            return
        }

        val expense = hashMapOf(
            "userId" to userId,
            "name" to name,
            "amount" to amount,
            "category" to category,
            "description" to descriptionText
        )

        FirestoreUtil(requireContext()).createOrUpdateDocument(
            collectionPath = "expenses",
            data = expense
        )
    }
}
